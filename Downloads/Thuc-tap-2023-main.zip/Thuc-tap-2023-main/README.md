# Thuc-tap-2023
Ghi chép lại quá trình thực tập tại VNPT-IT
